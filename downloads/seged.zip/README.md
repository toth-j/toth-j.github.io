# Segéd

Könnyebb, gyorsabb munka a Windows-ban:
- rövidítések,
- ...
